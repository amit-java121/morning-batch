package sorting;

import java.util.ArrayList;
import java.util.Collections;

public class EmployeeTest {
	
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.setEmpId(100);
		emp.setEmpName("rohan");
		emp.setEmpAddress("pune");
		
		Employee emp1 = new Employee();
		emp1.setEmpId(102);
		emp1.setEmpName("ajay");
		emp1.setEmpAddress("Mumbai");
		
		Employee emp2 = new Employee();
		emp2.setEmpId(101);
		emp2.setEmpName("sohan");
		emp2.setEmpAddress("pune");
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
		empList.add(emp);
		empList.add(emp1);
		empList.add(emp2);
		
		//System.out.println(empList);
		
		Collections.sort(empList);
		
		System.out.println(empList);
		//Collections.sort(empList);
	}

}
