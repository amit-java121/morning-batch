package inter;

public interface AI {
	
	void m1();
	String m2();

}
