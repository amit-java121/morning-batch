package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.User;

public class UserDBConnection {
	
	public User getUserDetailsFrmDb(String userEmail) {
		User user = new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
		    Statement stmt = con.createStatement();
		    ResultSet rs = stmt.executeQuery("select * from user where user_email='"+userEmail+"'");
			
			
		    while (rs.next()) {
				String username = rs.getString("user_email");
				String userpass= rs.getString("user_pass");
				user.setUserName(username);
				user.setUserPass(userpass);
			}
		    
		    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
	}

	public void saveUserData(User user) {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	    Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
	    
	    Statement stsmt = con.createStatement();
	    	int i = stsmt.executeUpdate("insert into user (user_name,user_mob,user_pass,gender,country,user_email) values('"+user.getUserName()+"',"+user.getMobNumber()+",'"+user.getUserPass()+"','"+user.getGender()+"','"+user.getCountry()+"','"+user.getUserEmail()+"')");
	    
	    	System.out.println("i "+i);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public List<User> getUserData() {
		List<User> userList = new ArrayList<User>();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	    Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
	    
	    Statement stsmt = con.createStatement();
	    ResultSet rs = stsmt.executeQuery("select * from user");
	    
	    while(rs.next()) {
	    	
	    	User user = new User();
	    	
	    	user.setId(Integer.valueOf(rs.getString("id")));
	    	user.setUserName(rs.getString("user_name"));
	    	user.setMobNumber(Long.valueOf(rs.getString("user_mob")));
	    	user.setGender(rs.getString("gender"));
	    	user.setUserPass(rs.getString("user_pass"));
	    	user.setCountry(rs.getString("country"));
	    	user.setUserEmail(rs.getString("user_email"));
	    	
	    	userList.add(user);
	    }
	    
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userList;
	}


}
