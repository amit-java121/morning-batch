package com.it.service;

public interface IUser {
	public void verifyUser(String username,String password);

}
