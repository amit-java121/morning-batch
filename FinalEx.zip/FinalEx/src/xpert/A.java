package xpert;

public class A {
	int bb;
	final int aa=10;
	
	void m1() {
		//aa=20;
		System.out.println("3333");
	}

}
