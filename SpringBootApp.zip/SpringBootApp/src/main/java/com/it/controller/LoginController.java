package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.it.service.IUser;

@RestController
public class LoginController {
	
	@Autowired
	IUser userservice;
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username, @RequestParam("password") String password) {
		
		System.out.println("username: "+username+" password "+password);
		
		userservice.verifyUser(username, password);
		
		return "hello i am logged in";
	}

}
