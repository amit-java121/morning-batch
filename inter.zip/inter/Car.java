package inter;

public class Car {
	
	static int bb=20;
	
	 public int weelsOfCar() {
		System.out.println("weels of car");
	
		 return 4;
	 }
	 
	 public String colorOfCar() {
			System.out.println("color of car");
		
			 return "green";
	}
	 
	 
	 public int engine() {
			System.out.println("engine of car");
		
			 return 1200;
	}


}
