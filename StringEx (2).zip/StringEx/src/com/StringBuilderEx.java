package com;

public class StringBuilderEx {

	public static void main(String[] args) {
		StringBuilder sbd = new StringBuilder("hello pune");
		//System.out.println(sbd.charAt(5));
		System.out.println(sbd.lastIndexOf("p"));
	}
}
