package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.it.dao.UserRepository;
import com.it.model.User;

public class UserServiceImpl implements IUser{

	@Autowired
	UserRepository repository;
	
	@Override
	public void verifyUser(String username, String password) {
		User user = repository.findByUserEmail(username);
		
		System.out.println(user.toString());
		//compare user name and password
	}

}
