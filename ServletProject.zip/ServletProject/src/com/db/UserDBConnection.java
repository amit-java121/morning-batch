package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.User;

public class UserDBConnection {
	
	public User getUserDetailsFrmDb(String userName) {
		User user = new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
		    Statement stmt = con.createStatement();
		    ResultSet rs = stmt.executeQuery("select * from user where user_name='"+userName+"'");
			
			
		    while (rs.next()) {
				String username = rs.getString("user_name");
				String userpass= rs.getString("user_pass");
				user.setUserName(username);
				user.setUserPass(userpass);
			}
		    
		    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
	}

	public void saveUserData(User user) {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	    Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
	    
	    Statement stsmt = con.createStatement();
	    	int i = stsmt.executeUpdate("insert into user (user_name,user_mob,user_pass,gender,country,user_email) values('"+user.getUserName()+"',"+user.getMobNumber()+",'"+user.getUserPass()+"','"+user.getGender()+"','"+user.getCountry()+"','"+user.getUserEmail()+"')");
	    
	    	System.out.println("i "+i);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
