package com;

public class ExceptionTest {
	
	void m1(int a,int b) {
		
		
		String str="";
		
		System.out.println("stmt 1");
		System.out.println("stmt 2");
		System.exit(0);
		//
		try {
			int c=a/b;
			//logic that is related database(fetch database from DB/file)
			//connection
			//fetch/insert/delete/update
			//complete
			//closed the connection
		//logic 
		}catch(Exception ae) {
			System.out.println("message we can pass message here::");
		}
		
		System.out.println("stmt 4");
		System.out.println("stmt 5");
		
		
		System.out.println("stmt 4");
		System.out.println("stmt 5");
		
		
	}
	
	
	public static void main(String[] args) {
		ExceptionTest et = new ExceptionTest();
		et.m1(10,0);
	}

}
