package xpert;

public class TestA {
	
	public static void main(String[] args) {
		A a = new A();
		System.out.println(a.aa);
		a.m2();
	}

}
