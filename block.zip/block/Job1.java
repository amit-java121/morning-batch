package block;

public class Job1 extends Thread{

	PrintNumber pn;
	
	public Job1(PrintNumber pn) {
		this.pn=pn;
	}
	
	@Override
	public void run() {
		pn.print();
	}
}
