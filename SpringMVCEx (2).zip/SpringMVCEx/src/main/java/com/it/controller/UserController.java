package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.IUserService;

@Controller
public class UserController {
	
	@Autowired
	IUserService userservice;
	
	
	@GetMapping("/")
	public String login() {
		
		System.out.println(" we are login method:: ");
		
		
		return "login";
	}
	
	@GetMapping("/login")
	public String userLogin(@RequestParam("userEmail") String userEmail,@RequestParam("password") String userpass,Model model) {
		System.out.println("user name"+userEmail+" pass: "+userpass);
		boolean flag = userservice.checkUserCredentials(userEmail,userpass);
		
		if(flag) {
			
			return "redirect:/get-user";
			
		}else {
			model.addAttribute("msg", "Your username/password is incorrect. please try again!!");
		}
		
		return "login";
		
	}
	
	@GetMapping("/user-form")
	public ModelAndView userForm() {
		ModelAndView model =  new ModelAndView("userForm");
		
		model.addObject("user", new User());
		
		return model;
	}
	
	@PostMapping("/save")
	public void saveUser(@ModelAttribute User user) {
		System.out.println("user data: "+user.toString());
		userservice.saveUser(user);
	}
	
	@GetMapping("/get-user")
	public String getUseData(Model model) {
		List<User> listOfUser = userservice.getUserDetails();
		
		model.addAttribute("userList", listOfUser);
		
		return "userdata";
	}
	
	
	@GetMapping("/delete")
	public String deleteUser(@RequestParam("id") int id,Model model){
	    System.out.println("user id: "+id);
		boolean flag = userservice.deleteUser(id);
		if(flag) {
			return "redirect:/get-user";
		}else {
			model.addAttribute("msg", "User record is not deleted. please try again::");
		}
		
		return "userForm";
	}
	
	@GetMapping("/edit")
	public String editUserData(@RequestParam("id") int id,Model model) {
		
		System.out.println("edit user id "+id);
		User user= userservice.editUser(id);
		
		model.addAttribute("user", user);
		return "userForm";
		
	}

}
