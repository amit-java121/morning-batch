package com.it.service;

import java.util.List;

import com.it.model.User;

public interface IUserService {

	boolean checkUserCredentials(String userEmail,String userPass);

	void saveUser(User user);
	List<User> getUserDetails();

	boolean deleteUser(int id);

}
