package com;

public class User {
	
	public User() {
		
	}
	
	private int userID =101;;
	
	private String getUserName() {
		
		return "xpert";
	}
	
	
	public static void main(String[] args) {
		User user = new User();
		System.out.println(user.userID);
		user.getUserName();
	}

}
