package com;

public class GetUserData {
	
	
	
	public static void main(String[] args) {
		GetUserData userData = new GetUserData();
		userData.getUserData();
	}
	
	
	public void getUserData() {
		
		JdbcEx jdbc = new JdbcEx();
		User userData = jdbc.fetchUserData();
		System.out.println(userData.getId());
		System.out.println(userData.getUserName());
		System.out.println(userData.getAddress());
		System.out.println(userData.getMobNumber());
		
	}

}
