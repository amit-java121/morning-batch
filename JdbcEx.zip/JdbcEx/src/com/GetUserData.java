package com;

import java.util.List;

public class GetUserData {
	
	
	
	public static void main(String[] args) {
		GetUserData userData = new GetUserData();
		//userData.getUserData();
		
		userData.fetchUsersListData();
	}
	
	
	public void getUserData() {
		
		JdbcEx jdbc = new JdbcEx();
		User userData = jdbc.fetchUserData();
		System.out.println(userData.getId());
		System.out.println(userData.getUserName());
		System.out.println(userData.getAddress());
		System.out.println(userData.getMobNumber());
		
	}
	
	
	public void fetchUsersListData() {
		JdbcEx jdbc = new JdbcEx();
		List<User> listOfUsers = jdbc.fetchListOfUsersData();
		
		for(User user:listOfUsers) {
			System.out.println(user.toString());
		}
		
	}

}
