package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.IUserDao;
import com.it.model.User;
@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	IUserDao userDao;
	
	public boolean checkUserCredentials(String userEmail,String userPAss) {

		System.out.println("we are in service impl");
		User user = userDao.verifyUserDetails(userEmail,userPAss);
		
		if( userEmail != null && userEmail.equalsIgnoreCase(user.getUserEmail()) && userPAss != null && userPAss.equalsIgnoreCase(user.getPassword())) {
			return true;
		}else {
			return false;
		}
		
	}

	@Override
	public void saveUser(User user) {
		userDao.saveUserData(user);
		
	}

}
