package pro;

import com.Student;

public class ProtectedTest extends Student {
	
	
	public static void main(String[] args) {
		ProtectedTest pt = new ProtectedTest();
		System.out.println(pt.stuId);
		pt.getStudentAddress();
		
//		Student st = new Student();
//		st.
	}

}
