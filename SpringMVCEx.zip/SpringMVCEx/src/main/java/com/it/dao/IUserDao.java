package com.it.dao;

public interface IUserDao {

	void verifyUserDetails(String userEmail,String userPass);

}
