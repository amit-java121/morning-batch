package inter;

public class TestVehicle {
	
	public static void main(String[] args) {
		NewCar car = new NewCar();
		String color = car.color();
		System.out.println(Vehicle.aa);
		System.out.println("car:: "+color);
		NewBike bike = new NewBike();
		int hp = bike.engine();
		System.out.println("bike "+hp);
	}

}
