package inheritance;

public class B extends A{

	int bb=20;
	
	public void m1() {
		System.out.println("B m2() called:: ");
	}
	
	
	public static void main(String[] args) {
		B b = new B();
		System.out.println(b.aa);
		System.out.println(b.bb);
		b.m1();
		//b.m2();

	}
}
