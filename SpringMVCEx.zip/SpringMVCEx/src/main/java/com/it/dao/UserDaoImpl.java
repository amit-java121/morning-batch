package com.it.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class UserDaoImpl implements IUserDao{

	@Autowired
	SessionFactory sessionFactory;
	
	public User verifyUserDetails(String userEmail,String userPass) {
		User userDetails = new User();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userEmail=:userEmail");
        List user = query.setParameter("userEmail", userEmail).getResultList();

        if(user.size() > 0) {
         userDetails = (User)user.get(0);
        }
		
		System.out.println("no we are in dao impl");
		
		return userDetails;
	}

	@Override
	public boolean saveUserData(User user) {
		
		boolean flag=false;
		try {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		flag=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
		
	}
	
	public List<User> getUserData() {
		
		Session session = sessionFactory.openSession();
		 Criteria cr = session.createCriteria(User.class);
		 List<User> listOfUser = cr.list();
		
		 return listOfUser;
	}

	@Override
	public boolean deleteUser(int id) {
		boolean flag=false;
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, id);
		try {
		    session.delete(user);
		    flag=true;
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
		return flag;
	}

	@Override
	public User editUser(int id) {
		
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, id);
		
		return user;
	}

}
