package com;

import java.io.Serializable;

public class Payment implements Serializable{
	private static int custId;
	private int cardNumber;
	private int cvvNo;
	private transient String customerName;
	
	public Payment(int custId, int cardNumber, int cvvNo, String customerName) {
		super();
		this.custId = custId;
		this.cardNumber = cardNumber;
		this.cvvNo = cvvNo;
		this.customerName = customerName;
	}
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public int getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getCvvNo() {
		return cvvNo;
	}
	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	

}
