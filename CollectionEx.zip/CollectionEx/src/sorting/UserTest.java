package sorting;

import java.util.ArrayList;
import java.util.Collections;

public class UserTest {
	
	public static void main(String[] args) {
		User user = new User(1000,"Ajay","Pune");
		User user1 = new User(1003,"Rohan","Pune");
		User user2 = new User(1004,"Sohan","mumbai");
		User user3 = new User(1002,"Bijay","Pune");
		
		ArrayList<User> userList = new ArrayList<>();
		
		userList.add(user);
		userList.add(user2);
		userList.add(user3);
		userList.add(user1);
		
		System.out.println(userList.toString());
		
		Collections.sort(userList, new IdComprator());
		
		System.out.println("Sorted on Id "+userList);
		
		Collections.sort(userList, new NameComparator());
		
		System.out.println("Sorted on name "+userList.toString());
		
	}

}
