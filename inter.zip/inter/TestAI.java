package inter;

public class TestAI implements AI{

	@Override
	public void m1() {
		//validate
		System.out.println("m1:::");
		
	}

	@Override
	public String m2() {
		//logic
		//System.out.println("m2() :::");
		return null;
	}
	
	
	public static void main(String[] args) {
		TestAI ta = new TestAI();
		ta.m1();
		ta.m2();
		
	}

}
