package com;

public class StringBufferEx {
	
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("xpert pune");
		
		sb.append(" hello");
		
		System.out.println("actaul:: "+sb);
//		StringBuffer sb2 = new StringBuffer();
//		System.out.println(sb2.capacity());
		
		//System.out.println("after delete:: "+sb.delete(6, 10));
//		System.out.println("size:: "+sb.length());
//		System.out.println("after replace::"+sb.replace(6, 10, "mumbai"));
	//	System.out.println("reverse:: "+sb.reverse());
		System.out.println("sub string:: "+sb.substring(6, 10));
		
	}

}
