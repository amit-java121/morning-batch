package sett;

import java.util.NavigableSet;
import java.util.TreeSet;

public class TreeSetTest {
	
	public static void main(String[] args) {
		TreeSet<String> treeSet = new TreeSet<>();
		treeSet.add("test");
		treeSet.add("test3");
		treeSet.add("test1");
		treeSet.add("test2");
		//treeSet.add(null);
		System.out.println(treeSet);
		NavigableSet<String> descSet = treeSet.descendingSet();
		System.out.println("desc:: "+descSet);
	
		System.out.println(treeSet.pollLast());
		//System.out.println(treeSet.);
		
	}

}
