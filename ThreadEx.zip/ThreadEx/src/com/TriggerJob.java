package com;

public class TriggerJob {
	
	public static void main(String[] args) {
		
	//	System.out.println("before job: "+Thread.currentThread().getName());
//		for(int i=0;i<10;i++) {
//			System.out.println("First for loop");
//		}
		Job j = new Job();
		j.start();
		j.setName("Amazon");
		//j.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Job j1 = new Job();
		j1.start();
		j1.setName("Flipkart");
//		System.out.println("After job: "+Thread.currentThread().getName());
//		for(int i=20;i<30;i++) {
//			System.out.println("Second for loop");
//		}
	}

}
