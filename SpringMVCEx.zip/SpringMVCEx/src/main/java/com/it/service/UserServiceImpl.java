package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.IUserDao;
@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	IUserDao userDao;
	
	public void checkUserCredentials(String userEmail,String userPAss) {

		System.out.println("we are in service impl");
		userDao.verifyUserDetails(userEmail,userPAss);
	}

}
