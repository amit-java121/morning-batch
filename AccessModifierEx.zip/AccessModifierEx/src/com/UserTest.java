package com;

import xpert.A;

public class UserTest {
	
	public static void main(String[] args) {
		//User user = new User();
		A a  = new A();
		
		Student st = new Student();
		st.getStudentAddress();
	}

}
