package map;

import java.util.Hashtable;

public class HashTableTest {
	
	public static void main(String[] args) {
		Hashtable<Integer, String> hashTable = new Hashtable<>();
		
		hashTable.put(101, "xyz1");
		hashTable.put(102, "xyz2");
		hashTable.put(104, "xyz4");
		hashTable.put(103, "xyz3");
		//hashTable.put(100, null);
		
		
		if(hashTable.get(102).contains("xyz1")) {
			System.out.println("true:: ");
		}else {
			System.out.println("false:: ");
		}
		
		System.out.println(hashTable);
	}

}
