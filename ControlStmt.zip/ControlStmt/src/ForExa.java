
public class ForExa {
	
	public static void main(String[] args) {
	aa:
		for (int i = 0; i < 5; i++) {
			System.out.println("inside first for loop");
		bb:
			for (int k = 0; k < 5; k++) {
				System.out.println("inside second for loop");
				
				if(k==2) {
					break bb;
				}
			}
		
			if(i==2) {
				break aa;
			}
		}
	}

}
