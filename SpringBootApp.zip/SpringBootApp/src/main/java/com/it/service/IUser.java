package com.it.service;

import java.util.List;

import com.it.model.User;

public interface IUser {
	public boolean verifyUser(String username,String password);

	public void saveUserdetails(User user);
	public List<User> getListOfUsers();

	public boolean deleteUserRecord(int id);

	public void updateUserRecord(User user);

}
