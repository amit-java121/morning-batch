package com;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListEx {
	
	public ArrayList userData() {
		
		ArrayList<String> arrayList = new ArrayList<String>();
		
		arrayList.add("amit");
		arrayList.add("rohan");
		arrayList.add("abc");
		arrayList.add("aaaaa");
		//arrayList.add(100);
//		
//		Iterator itr = arrayList.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		
		return arrayList;
		
	}

}
