package com;

public class B {
	
	public int add(int a,int b) {
		
		int c=a+b;
		System.out.println("in add method "+c);
		return c;
	}

}
