package map;

import java.util.TreeMap;

public class TreeMapTest {
	
	public static void main(String[] args) {
		
		TreeMap<Integer, String> treeMap = new TreeMap<>();
		treeMap.put(1000, "abc");
		treeMap.put(1003, "abc3");
		treeMap.put(1001, "abc1");
		treeMap.put(1002, "abc2");
//		treeMap.put(1004, null);
//		treeMap.put(1005, null);
		
		System.out.println(treeMap.descendingMap());
	}

}
