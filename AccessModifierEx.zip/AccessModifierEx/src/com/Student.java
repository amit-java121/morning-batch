package com;

public class Student {
	
	protected int stuId=1001;
	
	protected String getStudentAddress() {
		
		return "Pune MH";
	}

}
