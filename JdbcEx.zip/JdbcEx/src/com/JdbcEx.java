package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcEx {
	
	public static void main(String[] args) {
		
		
		
		
		try {
			System.out.println("step 1");
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 2");
			Connection con	= DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
			System.out.println("step 3");
			Statement stmt = con.createStatement();
			 ResultSet rs = stmt.executeQuery("select * from user");
			 while(rs.next()) {
				String id = rs.getString("id");
				 String userName= rs.getString("user_name");
				 String address = rs.getString("address");
				 String mobNum = rs.getString("user_mob");
				 
				 
				 System.out.println("id: "+id);
				 System.out.println("user name: "+userName);
				 System.out.println("address: "+address);
				 System.out.println("user mob: "+mobNum);
			 }
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}
	
	
	public User fetchUserData() {
		
		User user = new User();
		try {
			System.out.println("step 1");
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 2");
			Connection con	= DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
			System.out.println("step 3");
			Statement stmt = con.createStatement();
			 ResultSet rs = stmt.executeQuery("select * from user");
			 while(rs.next()) {
				Integer id = rs.getInt("id");
				 String userName= rs.getString("user_name");
				 String address = rs.getString("address");
				 String mobNum = rs.getString("user_mob");
				 user.setId(id);
				 user.setUserName(userName);
				 user.setAddress(address);
				 user.setMobNumber(Long.valueOf(mobNum));
				 
//				 System.out.println("id: "+id);
//				 System.out.println("user name: "+userName);
//				 System.out.println("address: "+address);
//				 System.out.println("user mob: "+mobNum);
			 }
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return user;
	}

	}


