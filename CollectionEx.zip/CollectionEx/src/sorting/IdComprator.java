package sorting;

import java.util.Comparator;

public class IdComprator implements Comparator<User>{

	@Override
	public int compare(User o1, User o2) {
		if(o1.getUserId() == o2.getUserId()) {
			return 0;
		}else if(o1.getUserId() > o2.getUserId()) {
			return 1;
		}else {
			return -1;
		}
	}

}
