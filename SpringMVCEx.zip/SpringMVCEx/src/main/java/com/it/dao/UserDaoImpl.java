package com.it.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements IUserDao{

	public void verifyUserDetails() {

		System.out.println("no we are in dao impl");
	}

}
