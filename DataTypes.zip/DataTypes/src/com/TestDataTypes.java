package com;

public class TestDataTypes {
	
	
	double dd;
	
	public static void main(String[] args) {
		byte b=127;
		int a=1111111111;
		long l=1111111111111111111l;
		
		float f=12.3f;
		double d=1222.333333333d;
		
		TestDataTypes td = new TestDataTypes();
		
		System.out.println(td.dd);
		
	}

}
