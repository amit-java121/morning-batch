package com;

public class ExceptionWithFinally {
	
	void m1(int a,int b) {
		try {
		System.out.println("stmt 1");
		int c=a/b;
		System.out.println("stmt 2");
		}catch(ArithmeticException e) {
			e.printStackTrace();
		}finally {
			//Db connection close 
			//file close 
			System.out.println("finally block executed::");
		}
		
		System.out.println("after finally::");
		
	}
	
	
	public static void main(String[] args) {
		ExceptionWithFinally ewf = new ExceptionWithFinally();
		ewf.m1(10,5);
	}

}
