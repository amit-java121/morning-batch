package com;

public class C {
	
	String str ="hello";
	
	void m1() {
		System.out.println(str.charAt(4));
		System.out.println(str.toUpperCase());
		System.out.println(str.length());
		
		String str1 = str.concat(" xpert it ");
		System.out.println(str1);
		
	}
	
	
	public static void main(String[] args) {
		C c = new C();
		c.m1();
	}

}
