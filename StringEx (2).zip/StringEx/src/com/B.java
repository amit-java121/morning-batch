package com;

public class B {
	
	
	
	void m1() {
		String str ="hello";
		String str1 ="hello";
		
		String str2 = new String("hello");
		String str3 = new String("hello");
		
		System.out.println(str.equals(str1));//false
		System.out.println(str.equals(str2));//true
		System.out.println(str2.equals(str3));//true
		
		System.out.println(str == str1);
		System.out.println(str == str2);
		System.out.println(str2 == str3);
		
	}
	
	public static void main(String[] args) {
		B b = new B();
		b.m1();
	}

}
