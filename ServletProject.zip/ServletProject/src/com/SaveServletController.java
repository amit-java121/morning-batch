package com;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.UserService;

/**
 * Servlet implementation class SaveServletController
 */
@WebServlet("/SaveServletController")
public class SaveServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveServletController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User user = new User();
		user.setUserName(request.getParameter("userName"));
		user.setUserPass(request.getParameter("password"));
		user.setUserEmail(request.getParameter("userEmail"));
		user.setGender(request.getParameter("gender"));
		user.setMobNumber(Long.valueOf(request.getParameter("userMBNumber")));
		user.setCountry(request.getParameter("country"));
		
		//Call service
		UserService userService = new UserService();
		boolean flag= userService.saveUserDetails(user);
		
		if(flag) {
			List<User> listOfUser= userService.getUserData();
			request.setAttribute("list", listOfUser);
			RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
		}else {
			request.setAttribute("message", "User record is not saved successfully, Please try again!!!");
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			rd.forward(request, response);
		}
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
