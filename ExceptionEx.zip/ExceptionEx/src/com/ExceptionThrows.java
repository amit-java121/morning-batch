package com;

public class ExceptionThrows {
	
	int m1(int b,int c) throws ArithmeticException{
		
		int a=b/c;
		
		return a;
	}
	
	
	void testM1() {
		try {
		m1(10,0);
		}catch(ArithmeticException e) {
			System.out.println("exception handlled::");
		}
	}

}
