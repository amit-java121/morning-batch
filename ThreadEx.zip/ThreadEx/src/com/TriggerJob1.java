package com;

public class TriggerJob1 {
	public static void main(String[] args) {
		
		Job1 j1 = new Job1();
		Thread th = new Thread(j1);
		th.start();
	}

}
