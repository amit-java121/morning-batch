package sorting;

import java.util.ArrayList;
import java.util.Collections;

public class CustomerTest {
	
	public static void main(String[] args) {
		Customer emp = new Customer();
		emp.setCustId(100);
		emp.setCustName("rohan");
		emp.setCustAddress("pune");
		
		Customer emp1 = new Customer();
		emp1.setCustId(102);
		emp1.setCustName("ajay");
		emp1.setCustAddress("Mumbai");
		
		Customer emp2 = new Customer();
		emp2.setCustId(101);
		emp2.setCustName("sohan");
		emp2.setCustAddress("pune");
		
		ArrayList<Customer> custList = new ArrayList<Customer>();
		custList.add(emp);
		custList.add(emp1);
		custList.add(emp2);
		
		System.out.println("before sorting :: "+custList);
		
		Collections.sort(custList);
		
		System.out.println("after sorting ::"+custList);
		//Collections.sort(empList);
	}

}
