package aggregation;

public class Cumstomer {

	int customerId;
	String customerName;
	long phoneNo;
	
	Address add;
	
}
