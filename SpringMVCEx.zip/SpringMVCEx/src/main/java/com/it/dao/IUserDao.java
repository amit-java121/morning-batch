package com.it.dao;

import com.it.model.User;

public interface IUserDao {

	User verifyUserDetails(String userEmail,String userPass);

	void saveUserData(User user);

}
