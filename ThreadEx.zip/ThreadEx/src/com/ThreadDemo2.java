package com;

public class ThreadDemo2 implements Runnable {

	@Override
	public void run() {
		System.out.println("runnable interface:::");
		
	}

}
