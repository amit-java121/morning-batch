package com;

public class ThrowTest {
	
	void m2(String userEmail) {
		
		if(userEmail.equalsIgnoreCase("amit@gmail.com")) {
			//save to DB
		}else {
			throw new IllegalArgumentException("Your user email is incorrect!");
		}
	}
	
	
	
	public static void main(String[] args) {
		ThrowTest tt = new ThrowTest();
		try {
		tt.m2("amitgmail.com");
		}catch(IllegalArgumentException ie) {
			System.out.println(ie.getMessage());
		}
	}

}
