package com.service;

import java.util.List;

import com.User;
import com.db.UserDBConnection;

public class UserService {
	
	public boolean checkUser(String userName,String userPass) {
		
		UserDBConnection userdb = new UserDBConnection();
		
		User userObj = userdb.getUserDetailsFrmDb(userName);
		System.out.println("user details:: "+userObj.toString());
		
		//logic verify user details
		if(userObj.getUserName() !=null && userObj.getUserName().equalsIgnoreCase(userName) && userObj.getUserPass() != null && userObj.getUserPass().equalsIgnoreCase(userPass)) {
			return true;
		}else {
			return false;
		}
	}

	public void saveUserDetails(User user) {

		UserDBConnection userdb = new UserDBConnection();
		userdb.saveUserData(user);
		
	}

	public List<User> getUserData(){
		UserDBConnection userdb = new UserDBConnection();
		
		List<User> userlist= userdb.getUserData();
		
		return userlist;
	}
}
