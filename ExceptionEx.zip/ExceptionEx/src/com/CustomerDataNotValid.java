package com;

public class CustomerDataNotValid extends Exception{
	private static final long serialVersionUID = 1L;
	
	int error;
	String message;
	
	public CustomerDataNotValid(int error, String message) {
		super();
		this.error = error;
		this.message = message;
	}

	public int getError() {
		return error;
	}

	public void setError(int error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
