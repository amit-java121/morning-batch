package xpert;

public class AA{
	
	void m1() {
		System.out.println("m1 AA called:::");
	}
	
	
	public static void main(String[] args) {
		//String str=null;
	}

}
