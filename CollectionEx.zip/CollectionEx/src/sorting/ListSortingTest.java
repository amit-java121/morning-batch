package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListSortingTest {
	
	public static void main(String[] args) {
		
		ArrayList<String> arrayList = new ArrayList<>();
		arrayList.add("ajay");
		arrayList.add("vijay");
		arrayList.add("amit");
		arrayList.add("rohan");
		
//		System.out.println("normal "+arrayList);
//		Collections.sort(arrayList);
//		System.out.println("sorted: "+arrayList);
		
		//Collections.sort(arrayList,Collections.reverseOrder());
		
		//System.out.println("sorted in reverse order:: "+arrayList);
		
//		System.out.println(Collections.min(arrayList));
//		System.out.println(Collections.max(arrayList));
		
//		List<String> unModifiableList = Collections.unmodifiableList(arrayList);
//		
//		unModifiableList.add("abc");
//		System.out.println(unModifiableList);
		
		 List<String> synchronizedList = Collections.synchronizedList(arrayList);
		
	}

}
