package xpert;

public final class BB {
	
   void m1() {
		System.out.println("m1 BB");
	}

}
