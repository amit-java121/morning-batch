package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.function.EntityResponse;

import com.it.model.User;
import com.it.service.IUser;

@RestController
public class LoginController {
	
	@Autowired
	IUser userservice;
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username, @RequestParam("password") String password) {
		
		System.out.println("username: "+username+" password "+password);
		
		if(userservice.verifyUser(username, password)) {
			return "hello i am logged in";
		}
		
//		boolean flag = userservice.verifyUser(username, password);
//		
//		if(flag) {
//			return "hello i am logged in";
//			
//		}
		return "Your user name and password is wrong please try again!!";
	}
	
	@PostMapping("/save")
	public User saveUserDetails(@RequestBody User user) {
		System.out.println("user: "+user.toString());
		
		userservice.saveUserdetails(user);
		return user;
	}
	
	@GetMapping("/getData")
	public List<User> getUserData() {
		List<User> listOfUsers = userservice.getListOfUsers();
		
		return listOfUsers;
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteUserRecord(@PathVariable("id") int id) {
		
		System.out.println("user id : "+id);
		boolean flag =userservice.deleteUserRecord(id);
		
		if(flag) {
			 return new ResponseEntity<>("Record is deleted successfully", HttpStatus.OK);
		}
		
		return  new ResponseEntity<>("Record is not deleted", HttpStatus.NOT_FOUND);
	}
	
	@PutMapping("/update")
	public void updateRecord(@RequestBody User user) {
		System.out.println("user "+user.toString());
		userservice.updateUserRecord(user);
	}

}
