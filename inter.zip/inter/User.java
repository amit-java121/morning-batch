package inter;

public abstract class User {
	
	public abstract void m2();
	
	
	void m1() {
		
		System.out.println("m1::: ");
	}

}
