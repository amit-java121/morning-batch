package com;

public class ExceptionEx2 {
	
	void m2() {
		System.out.println("m2 called:: ");
	}
	
	void m1(int a,int b) {
		ExceptionEx2 ee=null;
			System.out.println("stmt 1");
			System.out.println("stmt 2");
			//
			try {
			System.out.println("before exception ::");
			ee.m2();
			
				int c=a/b;
			
			System.out.println("c= "+c);
			
			}catch(ArithmeticException ae) {
				ae.printStackTrace();
			}catch(Exception e) {
				System.out.println("exception catch block::");
				e.printStackTrace();
			}
			
			System.out.println("stmt 4");
			System.out.println("stmt 5");
			
			
		}
	
	public static void main(String[] args) {
		ExceptionEx2 ee2 = new ExceptionEx2();
		ee2.m1(10, 0);
	}

}
