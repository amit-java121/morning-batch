
public class SwitchTest {
	
	public String getMonthName(int code) {
		
		String monthName="";
		
		switch (code) {
		case 01:
			monthName="JAN";
			break;

		case 02:
			monthName="FEB";
			break;
		case 03:
			monthName="MAR";
			break;
		case 04:
			monthName="APR";
			break;
		case 05:
			monthName="MAY";
			break;
			
		default:
			monthName="None";
			break;
		}
		
		return monthName;
		
	}
	
	public static void main(String[] args) {
		
		SwitchTest st = new SwitchTest();
		String monthName = st.getMonthName(07);
		System.out.println(monthName);
		
	}

}
