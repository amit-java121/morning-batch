package block;

public class PrintNumber {
	
	public void print() {
		
		System.out.println("num1");
		System.out.println("num2");
		System.out.println("num3");
		System.out.println("num4");
		
		synchronized (this) {
			for(int i=0;i<10;i++) {
				System.out.println("i="+i);
			}
		}
		
		
		
		System.out.println("num5");
		System.out.println("num6");
		System.out.println("num7");
		System.out.println("num8");
		
	}

}
