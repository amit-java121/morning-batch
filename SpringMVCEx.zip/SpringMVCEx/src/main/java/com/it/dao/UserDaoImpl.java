package com.it.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class UserDaoImpl implements IUserDao{

	@Autowired
	SessionFactory sessionFactory;
	
	public User verifyUserDetails(String userEmail,String userPass) {
		
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userEmail=:userEmail");
     List user = query.setParameter("userEmail", userEmail).getResultList();

     User userDetails= (User)user.get(0);
     
     System.out.println(userDetails.toString());
		
		
		System.out.println("no we are in dao impl");
		
		return userDetails;
	}

	@Override
	public void saveUserData(User user) {

		Session session = sessionFactory.openSession();
		session.save(user);
		
	}
	
	public List<User> getUserData() {
		
		Session session = sessionFactory.openSession();
		 Criteria cr = session.createCriteria(User.class);
		 List<User> listOfUser = cr.list();
		
		 return listOfUser;
	}

	@Override
	public boolean deleteUser(int id) {
		boolean flag=false;
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		User user = session.get(User.class, id);
		try {
		    session.delete(user);
		    tr.commit();
		   
		    flag=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

}
