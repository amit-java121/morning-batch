package com;

public class TestRunnableInterface {
	
	public static void main(String[] args) {
		ThreadDemo2 td2 = new ThreadDemo2();
		Thread th = new Thread(td2);
		th.start();
	}

}
