package sorting;

public class Customer implements Comparable<Customer>{
	private int custId;
	private String custName;
	private String custAddress;
	


	@Override
	public int compareTo(Customer cust) {
		
		return custName.compareTo(cust.getCustName());
	}
	
	

	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public String getCustAddress() {
		return custAddress;
	}



	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}



	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", custAddress=" + custAddress + "]";
	}



}
