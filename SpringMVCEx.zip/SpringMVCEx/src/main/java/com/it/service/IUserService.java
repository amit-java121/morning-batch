package com.it.service;

import com.it.model.User;

public interface IUserService {

	boolean checkUserCredentials(String userEmail,String userPass);

	void saveUser(User user);

}
