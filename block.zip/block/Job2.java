package block;

public class Job2 extends Thread{

	PrintNumber pn;
	
	public Job2(PrintNumber pn) {
		this.pn=pn;
	}
	
	@Override
	public void run() {
		pn.print();
	}
}
