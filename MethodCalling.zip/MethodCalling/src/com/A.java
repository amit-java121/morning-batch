package com;

public class A {
	int a=10;
	String str="xpert";
	
	public void m1() {
		B b = new B();
	
		int bb = b.add(10,20);
		
		System.out.println("result: "+bb);
		
		System.out.println("hello");
	}
	
	
	
	public static void main(String[] args) {
	
		A a = new A();
		a.m1();
		System.out.println(a.a);
		System.out.println(a.str);
	}

}
