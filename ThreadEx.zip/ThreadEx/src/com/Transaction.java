package com;

public class Transaction extends Thread{

	static int balance=1000;
	
	@Override
	public void run() {
		for(int i=0;i<10;i++) {
			withdraw(150);
		}
	}

	private static synchronized void withdraw(int amt) {
		
		
		System.out.println("Thread trying to withdraw:: "+Thread.currentThread().getName());
		if(balance>200) {
			balance = balance-amt;
			System.out.println("withdrawn amount:: "+balance);
		}else {
			System.out.println("in sufficiant balance::: ");
		}
		
	}
}
