package com.it.service;

public interface IUserService {

	void checkUserCredentials(String userEmail,String userPass);

}
