package map;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LinkedHashMapTest {
	
	public static void main(String[] args) {
		
		LinkedHashMap<Integer, String> linkedHashMap = new LinkedHashMap<>();
		linkedHashMap.put(100, "abc");
		linkedHashMap.put(102, "abc2");
		linkedHashMap.put(101, "abc1");
		linkedHashMap.put(103, "abc3");
		linkedHashMap.put(100, "duplicate");
		System.out.println(linkedHashMap);
		
		for(Entry<Integer, String> map:linkedHashMap.entrySet()) {
			System.out.println("key : "+map.getKey()+ " value:: "+map.getValue());
		}
		
	}

}
