package xpert;

public class TestA  extends A{

	void m1() {
		//aa=30;
		System.out.println("2222");
	}
}
