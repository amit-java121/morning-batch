package xpert;

public class A {
	
	public A() {}
	
	int aa=10;
	
	void m2() {
		System.out.println("m2 from A");
	}

}
