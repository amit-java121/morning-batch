package inter;

public class UserTest extends User{

	@Override
	public void m2() {

		//logic
		System.out.println("m2 impl::: ");
		
	}
	
	
	public static void main(String[] args) {
		UserTest ut = new UserTest();
		ut.m1();
		ut.m2();
	}

}
