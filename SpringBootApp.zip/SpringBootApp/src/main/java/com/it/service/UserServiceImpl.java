package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.UserRepository;
import com.it.model.User;
@Service
public class UserServiceImpl implements IUser{

	@Autowired
	UserRepository repository;
	
	@Override
	public boolean verifyUser(String username, String password) {
		//User user = repository.findByUserEmail(username);
		
		User user = repository.findByUserEmailQuery(username);
		//System.out.println(user.toString());
		//compare user name and password
		
		if(user != null && user.getUserEmail().equalsIgnoreCase(username) && user.getPassword().equalsIgnoreCase(password)) {
			return true;
		}
		
		return false;
		
	}

	@Override
	public void saveUserdetails(User user) {

		repository.save(user);
	}
	
	public List<User> getListOfUsers() {
		List<User> listOfUser = repository.findAll();
		
		return listOfUser;
	}

	@Override
	public boolean deleteUserRecord(int id) {
		boolean flag = true;
		try {
			repository.deleteById(id);
		} catch (Exception e) {
			flag = false;
		}

		return flag;
	}

	@Override
	public void updateUserRecord(User user) {
		User userDb = repository.getById(user.getId());
		
		userDb.setUsername(user.getUsername());
		userDb.setUserEmail(user.getUserEmail());
		userDb.setPassword(user.getPassword());
		userDb.setGender(user.getGender());
		userDb.setCountry(user.getCountry());
		
		repository.save(userDb);
		
	}

}
