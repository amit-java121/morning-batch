package encapsulation;

public class TestCustomer {
	
	public static void main(String[] args) {
		Customer customer = new Customer(101,"abc","pune");
		System.out.println(customer.getCustId());
		System.out.println(customer.getCustName());
		System.out.println(customer.getCustAddress());
		
		//customer.setCustAddress("mumbai");
		
		System.out.println(customer.getCustAddress());
		customer.print();
	}

}
