package com;

public class ThrowsTest {
	
	public static void main(String[] args) {
		ExceptionThrows et = new ExceptionThrows();
		try {
		et.m1(10, 0);
		}catch(Exception e) {
			System.out.println("exception hanlled"+e.getMessage());
		}
	}

}
