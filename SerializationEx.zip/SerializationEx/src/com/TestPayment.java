package com;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class TestPayment {
	
	
	public static void main(String[] args) {
		
		Payment payment = new Payment(1000, 123456789, 123, "xyz");
		//byte stream
		
		try {
			
			FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test.txt");
			
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(payment);
			
			oos.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
