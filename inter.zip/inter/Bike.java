package inter;

public class Bike {
	
	public int weelsOfBike() {
		System.out.println("weels of bike");
		return 2;
	}
	
	public String color() {
		System.out.println("color of bike");
		return "Yellow";
	}
	
	public int engineOfBike() {
		System.out.println("engine of bike");
		return 150;
	}

}
