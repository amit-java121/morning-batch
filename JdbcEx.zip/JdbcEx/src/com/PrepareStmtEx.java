package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class PrepareStmtEx {
	
	
	public static void main(String[] args) {
		PrepareStmtEx pst = new PrepareStmtEx();
		pst.usePrepareStmt();
	}
	
	public void usePrepareStmt() {
		try {
		System.out.println("step 1");
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 2");
		Connection con	= DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
		System.out.println("step 3");
		
		PreparedStatement pstmt = con.prepareStatement("insert into user values(?,?,?,?)");
		
		pstmt.setInt(1, 105);
		pstmt.setString(2, "test user");
		pstmt.setString(3, "Nagpur");
		pstmt.setInt(4, 22222222);
		
		int i= pstmt.executeUpdate();
		System.out.println("iii: "+i);
		//Statement stmt = con.createStatement();
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
