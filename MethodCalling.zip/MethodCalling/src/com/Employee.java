package com;

public class Employee {
	int empId= 1010;
	String empName="xpert";
	String address="Pune";
	static String companyName="Accenture";
	
	
	public static void main(String[] args) {
		Employee emp = new Employee();
		
		Employee emp1 = new Employee();
		
		System.out.println(emp.address);
		System.out.println(emp.companyName);
		System.out.println(Employee.companyName);
		
		
		System.out.println(emp1.empName);
		
	}

}
