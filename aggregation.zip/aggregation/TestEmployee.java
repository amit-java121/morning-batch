package aggregation;

public class TestEmployee {
	
	public Employee setData() {
		Employee emp = new Employee();
		emp.setEmpId(100);
		emp.setEmpName("xpertit");
		emp.setMobileNo(1101010101010l);
		//
		Address add = new Address();
		
		add.setState("MH");
		add.setCity("Pune");
		add.setPincode(411013);
		add.setAreaName("Magarpatta");
		add.setStreetName("annexe");
		emp.setAddress(add);
		
		return emp;
	}
	
	public static void main(String[] args) {
		TestEmployee te = new TestEmployee();
		Employee employee = te.setData();
		
		System.out.println(employee.getEmpId());
		System.out.println(employee.getEmpName());
		System.out.println(employee.getAddress().getState());
		Address add = employee.getAddress();
		System.out.println(add.getAreaName());
		System.out.println(add.getCity());
	}

}
