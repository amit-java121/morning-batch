package com;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeSerializationTest {
	
	public static void main(String[] args) {
		
		try {
			FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\test.txt");
			
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			Payment payment = (Payment)ois.readObject();
			
			System.out.println("customer id: "+payment.getCustId());
			System.out.println("customer name: "+payment.getCustomerName());
			System.out.println("card number "+payment.getCardNumber());
			System.out.println("CVV : "+payment.getCvvNo());
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
