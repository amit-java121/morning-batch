
public class DoWhileTest {

	public static void main(String[] args) {
		
		int a=0;
		do {
			
			System.out.println("inside do block:: ");
			a++;
		} while (a<10);
	}
	
	
}
