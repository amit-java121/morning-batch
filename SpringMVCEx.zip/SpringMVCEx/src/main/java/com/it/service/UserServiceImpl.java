package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserDao;
import com.it.model.User;
@Service
@Transactional
public class UserServiceImpl implements IUserService{

	@Autowired
	IUserDao userDao;
	
	public boolean checkUserCredentials(String userEmail,String userPAss) {

		System.out.println("we are in service impl");
		User user = userDao.verifyUserDetails(userEmail,userPAss);
		
		if( userEmail != null && userEmail.equalsIgnoreCase(user.getUserEmail()) && userPAss != null && userPAss.equalsIgnoreCase(user.getPassword())) {
			return true;
		}else {
			return false;
		}
		
	}

	@Override
	public boolean saveUser(User user) {
		
		return userDao.saveUserData(user);
		
	}

	@Override
	public List<User> getUserDetails() {
		
		List<User> userList= userDao.getUserData();
		return userList;
	}

	@Override
	public boolean deleteUser(int id) {

		return userDao.deleteUser(id);
		
	}

	@Override
	public User editUser(int id) {
		return userDao.editUser(id);
	}

}
