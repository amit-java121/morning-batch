
public class A {

	
	public static void main(String[] args) {
		int a=10;
		
		
		if(a>10) {
			System.out.println("ababa");
		}else if(a==10) {
			System.out.println("ababab");
		}else if(a<10) {
			System.out.println("nnnn");
		}else {
			System.out.println("nnn");
		}
		
//		if(a>10) {
//			System.out.println("inside if::");
//			if(a<10) {
//				System.out.println();
//			}
//		}else {
//			System.out.println("inside else:: ");
//		}
	}
}
