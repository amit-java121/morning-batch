package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.it.service.IUserService;

@Controller
public class UserController {
	
	@Autowired
	IUserService userservice;
	
	
	@GetMapping("/")
	public String login() {
		
		System.out.println(" we are login method:: ");
		
		userservice.checkUserCredentials();
		return "login";
	}

}
