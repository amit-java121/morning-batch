package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String>  hashMap = new HashMap<>();
		hashMap.put(100, "abc");
		//hashMap.put(100, "abc1");
		hashMap.put(102, "abc2");
		hashMap.put(103, "abc3");
		hashMap.put(104, "abc4");
		hashMap.put(106, "pqr");
		hashMap.put(105, null);
		
		System.out.println("size:: "+hashMap.size());
		//System.out.println(hashMap);
		
		for(Entry<Integer, String> map:hashMap.entrySet()) {
			System.out.println("key "+map.getKey() +" value "+map.getValue());
		}
		
		hashMap.remove(105);
		System.out.println(hashMap);
		
		hashMap.putIfAbsent(106, "xyz");
		
		hashMap.replace(100, "abc", "AAAAA");
		System.out.println(hashMap);
		
		//merge 
		
		HashMap<Integer, String>  hashMap2 = new HashMap<>();
		hashMap2.put(110, "ttttt");
		hashMap2.put(111, "ttttt");
		
		hashMap.putAll(hashMap2);
		
		hashMap.clear();
		System.out.println("empty:: "+hashMap);
		
	}

}
