package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.IUserService;

@Controller
public class UserController {
	
	@Autowired
	IUserService userservice;
	
	
	@GetMapping("/")
	public String login() {
		
		System.out.println(" we are login method:: ");
		
		
		return "login";
	}
	
	@GetMapping("/login")
	public void userLogin(@RequestParam("userEmail") String userEmail,@RequestParam("password") String userpass) {
		System.out.println("user name"+userEmail+" pass: "+userpass);
		userservice.checkUserCredentials(userEmail,userpass);
	}

}
