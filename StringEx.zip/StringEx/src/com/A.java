package com;

public class A {
	
	String name="xpert";
	
	String m1() {
		String newName = new String("xpert it");
		System.out.println(newName);
		return newName;
	}
	
	public static void main(String[] args) {
		A a = new A();
		
		String newName= a.m1();
		System.out.println(newName);
		System.out.println(a.name);
	}

}
