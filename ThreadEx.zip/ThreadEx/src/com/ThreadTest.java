package com;

public class ThreadTest {
	
	public static void main(String[] args) {
		
		ThreadDemo td = new ThreadDemo();
		td.start();
	}

}
