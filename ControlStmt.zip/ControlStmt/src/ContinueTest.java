
public class ContinueTest {
	
	public static void main(String[] args) {
		
//			for (int i = 0; i < 2; i++) {
//				System.out.println("inside first for loop");
				
				for (int k = 0; k < 4; k++) {
					System.out.println("inside second for loop");
					
					if(k==1) {
						
						System.out.println("inside if::");
						continue;
					}
					
					System.out.println("outside if:: ");
				}
			
//				if(i==2) {
//				
//				}
//			}
		}

}
