package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class InsertUserData {
	
	
	public static void main(String[] args) {
		
		List<User> listOfUser = new ArrayList<User>();
		
		User user = new User();
		user.setId(103);
		user.setUserName("rohan");
		user.setAddress("pune");
		user.setMobNumber(101010100l);
		User user1 = new User();
		user1.setId(104);
		user1.setUserName("rushikesh");
		user1.setAddress("mumbai");
		user1.setMobNumber(101010111l);
		
		listOfUser.add(user);
		listOfUser.add(user1);
		
		InsertUserData iud = new InsertUserData();
		iud.insertRecord(listOfUser);
	
	}
	
	
	
	public void insertRecord(List<User> userList) {
		try {
			System.out.println("step 1");
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 2");
			Connection con	= DriverManager.getConnection("jdbc:mysql://localhost:3306/b13","root","root");
			System.out.println("step 3");
			Statement stmt = con.createStatement();
			
			for(User user:userList) {
				int i = stmt.executeUpdate("insert into user values("+user.getId()+",'"+user.getUserName()+"','"+user.getAddress()+"',"+user.getMobNumber()+")");
				System.out.println("number:: "+i); 
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}

}
