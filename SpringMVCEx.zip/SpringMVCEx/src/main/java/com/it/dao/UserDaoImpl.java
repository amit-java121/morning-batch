package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class UserDaoImpl implements IUserDao{

	@Autowired
	SessionFactory sessionFactory;
	
	public void verifyUserDetails(String userEmail,String userPass) {
		
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userEmail=:userEmail");
     List user = query.setParameter("userEmail", userEmail).getResultList();

     User userDetails= (User)user.get(0);
     
     System.out.println(userDetails.toString());
		
		
		System.out.println("no we are in dao impl");
	}

}
