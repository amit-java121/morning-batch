package inheritance;

public class NewUser extends User{
   long adhaarCardNo;

  
	public NewUser(int userId, String userName, String userAddress, long adhaarCardNo) {
		super(userId, userName, userAddress);
		this.adhaarCardNo = adhaarCardNo;
	}

	public long getAdhaarCardNo() {
		return adhaarCardNo;
	}
	
	public void setAdhaarCardNo(long adhaarCardNo) {
		this.adhaarCardNo = adhaarCardNo;
	}
 
 
}
