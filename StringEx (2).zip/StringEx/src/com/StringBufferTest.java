package com;

public class StringBufferTest{
	
	
	
	public static void main(String[] args) {
		 String str="hello";//literals//immutable
		//String str1 = new String("hello");//using new keyword
		// str.concat(" xpert");
		 String str2= str.concat(" xpert");
		System.out.println(str);
		
		StringBuffer sb = new StringBuffer("it is expert inst");//mutable
		sb.append(" in pune");
		System.out.println(sb);
		
	}

}
