package inter;

public interface Vehicle {
	int aa=10;
	
	int weels();
	String color();
	int engine();

}
