package com.it.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{

	//User findByUserEmail(String username);

	@Query("select u from User u where u.userEmail =:userEmail ")
	User findByUserEmailQuery(@Param("userEmail") String userEmail);
	
	

}
