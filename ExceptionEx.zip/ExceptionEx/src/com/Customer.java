package com;

public class Customer {
	
	void m2(String userEmail) throws CustomerDataNotValid {
			
			if(userEmail.equalsIgnoreCase("amit@gmail.com")) {
				//save to DB
			}else {
				throw new CustomerDataNotValid(100, "your user email is not valid::");
			}
		}
	
	
	void m3(String userEmail) throws CustomerDataNotValid {
		m2("abc@gmail.com");
	}
	
	void m4(String usermeial) throws CustomerDataNotValid {
		m3("xyz@mail.com");
	}
	
	public static void main(String[] args) {
		Customer customer = new Customer();
		
			//customer.m2("amitgmail.com");
			try {
				customer.m4("amitgmail.com");
			} catch (CustomerDataNotValid e) {
				System.out.println(e.getMessage());
			}
		
	}

}
