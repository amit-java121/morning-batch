package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface IUserDao {

	User verifyUserDetails(String userEmail,String userPass);

	void saveUserData(User user);
	List<User> getUserData();

	boolean deleteUser(int id);

}
