package com;

public class Employee {
	private int epmId;
	private String empName;
	private String empAddress;
	
	public int getEpmId() {
		return epmId;
	}
	public void setEpmId(int epmId) {
		this.epmId = epmId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	
	@Override
	public String toString() {
		return "Employee [[epmId=" + epmId + ", empName=" + empName + ", empAddress=" + empAddress + "]]";
	}

}
