package com;

import java.util.ArrayList;

public class EmployeeTest {
	
	
	public ArrayList<Employee> setEmpData() {
		
		Employee employee = new Employee();
		employee.setEpmId(100);
		employee.setEmpName("rohan");
		employee.setEmpAddress("Pune");
		
		Employee employee1 = new Employee();
		employee1.setEpmId(101);
		employee1.setEmpName("rohan1");
		employee1.setEmpAddress("Mumbai");
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
		empList.add(employee);
		empList.add(employee1);
		
		return empList;
	}
	
	
	
	public static void main(String[] args) {
		EmployeeTest et = new EmployeeTest();
		ArrayList<Employee> listOfEmployee = et.setEmpData();
		
		for(Employee empl:listOfEmployee) {
			System.out.println(empl.toString());
//			System.out.println(empl.getEpmId());
//			System.out.println(empl.getEmpName());
//			System.out.println(empl.getEmpAddress());
		}
	}

}
