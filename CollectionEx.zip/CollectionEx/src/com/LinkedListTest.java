package com;

import java.util.LinkedList;

public class LinkedListTest {
	
	public static void main(String[] args) {
		
		LinkedList<String> linkedList = new LinkedList<>();
		linkedList.add("xyz");
		linkedList.add("xyz");
		linkedList.add("xyz2");
		linkedList.add(null);
		for(String list:linkedList) {
			System.out.println(list);
		}
		
	}

}
