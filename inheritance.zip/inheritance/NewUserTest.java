package inheritance;

public class NewUserTest {
	
	public static void main(String[] args) {
		NewUser newUser = new NewUser(101,"abc","Pune",12345987l);
		
		System.out.println(newUser.getAdhaarCardNo());
		System.out.println(newUser.getUserId());
		System.out.println(newUser.getUserName());
		System.out.println(newUser.getUserAddress());
		
	}

}
