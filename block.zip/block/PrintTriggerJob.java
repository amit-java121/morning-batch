package block;

public class PrintTriggerJob {
	
	public static void main(String[] args) {
		PrintNumber pn = new PrintNumber();
		Job1 j1 = new Job1(pn);
		j1.start();
		Job2 j2 = new Job2(pn);
		j2.start();
	}

}
