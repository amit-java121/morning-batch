package inter;

public class NewCar implements Vehicle {

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "megma grey";
	}

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 1200;
	}

}
