package com.service;

import java.util.List;

import com.User;
import com.db.UserDBConnection;

public class UserService {
	
	public boolean checkUser(String userName,String userPass) {
		
		UserDBConnection userdb = new UserDBConnection();
		
		User userObj = userdb.getUserDetailsFrmDb(userName);
		System.out.println("user details:: "+userObj.toString());
		
		//logic verify user details
		if(userObj.getUserName() !=null && userObj.getUserName().equalsIgnoreCase(userName) && userObj.getUserPass() != null && userObj.getUserPass().equalsIgnoreCase(userPass)) {
			return true;
		}else {
			return false;
		}
	}

	public boolean saveUserDetails(User user) {

		UserDBConnection userdb = new UserDBConnection();
		boolean flag = userdb.saveUserData(user);
		return flag;
		
	}

	public List<User> getUserData(){
		UserDBConnection userdb = new UserDBConnection();
		
		List<User> userlist= userdb.getUserData();
		
		return userlist;
	}

	public boolean deleteUser(String userID) {
		
		UserDBConnection userdb = new UserDBConnection();
		boolean flag = userdb.deleteUserRecord(userID);
		
		return flag;
	}

	public User fetchSingleUserRecord(Integer id) {
		UserDBConnection userdb = new UserDBConnection();
		User user = userdb.getSingleUser(id);
		
		return user;
	}

	public boolean updateUserDetails(User user) {
		UserDBConnection userdb = new UserDBConnection();
		return userdb.updateUserDetails(user);
	}
	
	
}
