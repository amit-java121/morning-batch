package inheritance;

public class A {
	
	int aa=10;
	
	public void m1() {
		System.out.println("A m1() called :: ");
	}

}
