package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class EmployeeTest {
	
	
	public HashMap<Integer, Employee> empData() {
		HashMap<Integer, Employee> empHashMap = new HashMap<Integer, Employee>();
		Employee employee = new Employee(1000, "test", "Pune");
		Employee employee1 = new Employee(1001, "test1", "Mumbai");
		Employee employee2 = new Employee(1002, "test2", "Nagpur");
		Employee employee3 = new Employee(1003, "test3", "Pune");
		
		empHashMap.put(employee.getEmpId(), employee);
		empHashMap.put(employee1.getEmpId(), employee1);
		empHashMap.put(employee2.getEmpId(), employee2);
		empHashMap.put(employee3.getEmpId(), employee3);
		
		return empHashMap;
	}
	
	
	
	
	public static void main(String[] args) {
		
		EmployeeTest et = new EmployeeTest();
		HashMap<Integer, Employee> empData = et.empData();
		for(Entry<Integer, Employee> emp:empData.entrySet()) {
			System.out.println("emp key: "+emp.getKey() +" emp valye "+emp.getValue());
		}
		
		System.out.println(empData.get(1000));
		
	}

}
