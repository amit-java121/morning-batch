package com;

public class OperatorsEx {
	
	
	public static void main(String[] args) {
		
		int a=10;
		
		//System.out.println(10<<3);
		
		//System.out.println(10>>3);
		
		//System.out.println(++a);//11
		//System.out.println(a);//10
		
		int b=5;
		//a=b;
		
		//System.out.println(a==b);
		
		//System.out.println(a*b);
		
		if(a==b && b==a) {
			System.out.println("true");
		}
		
		System.out.println((a<b)?a:b);
		
	}

}
