package staticex;

public class TestStaticEx {
	
	int aa=30;
	static int bb=40;
	
	void m1() {
		m2();
	}
	
	 void m2() {
		 bb=100;
			m3();
		}
	
	static void m3() {
		bb=60;
		//aa=50;
		TestStaticEx ts = new TestStaticEx();
			ts.m2();
	}
	
	public static void main(String[] args) {
		TestStaticEx ts = new TestStaticEx();
		ts.m1();
		ts.m2();
		TestStaticEx.m3();
		//10-02-2021// 02-12-2021//2021-01-30//
	}

}
