package com;

public class ExceptionTest {
	
	void m1(int a,int b) {
		
		System.out.println("stmt 1");
		System.out.println("stmt 2");
		//
		try {
		System.out.println("before exception ::");
			int c=a/b;
		
		System.out.println("c= "+c);
		
		}catch(ArithmeticException ae) {
			ae.printStackTrace();
		}
		
		System.out.println("stmt 4");
		System.out.println("stmt 5");
		
		
	}
	
	
	public static void main(String[] args) {
		ExceptionTest et = new ExceptionTest();
		et.m1(10,0);
	}

}
