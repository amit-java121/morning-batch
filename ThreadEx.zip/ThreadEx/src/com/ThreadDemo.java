package com;

public class ThreadDemo extends Thread{
	 
	public void run() {
		System.out.println("run method executed:::");
	}

}
