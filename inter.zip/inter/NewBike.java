package inter;

public class NewBike implements Vehicle{

	@Override
	public int weels() {
		
		return 2;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "red";
	}

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 150;
	}

}
