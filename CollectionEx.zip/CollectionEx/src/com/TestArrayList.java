package com;

import java.util.ArrayList;

public class TestArrayList {
	
	public static void main(String[] args) {
		ArrayListEx listObj = new ArrayListEx();
		ArrayList userData = listObj.userData();
		
		System.out.println("size::"+userData.size());
		
		for(Object user:userData) {
			System.out.println("user name: "+user);
			
		}
	}

}
