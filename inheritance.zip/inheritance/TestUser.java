package inheritance;

public class TestUser {
	
	public void printUserDetails() {
		
		User user = new User(100,"Amit","pune");
//		User user = new User();
//		
//		user.setUserId(100);
//		user.setUserName("Amit");
//		user.setUserAddress("Pune");
		
		System.out.println(user.getUserId());
		System.out.println(user.getUserName());
		System.out.println(user.getUserAddress());
	}
	
	public static void main(String[] args) {
		
		TestUser tu = new TestUser();
		tu.printUserDetails();
		
	}

}
